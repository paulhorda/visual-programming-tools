package task2;

interface Game {
    void play();
}
